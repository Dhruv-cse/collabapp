import { useEffect, useRef, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { Save, ArrowLeft, Users, FileText, CheckCircle2 } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import socket from "../socket";

export default function CollaborativeEditor() {
  const { id } = useParams();
  const navigate = useNavigate();

  const [text, setText] = useState("");
  const [cursors, setCursors] = useState([]);
  const [saveStatus, setSaveStatus] = useState("Saved");

  const saveTimeout = useRef(null);
  const username = localStorage.getItem("username") || "User";

  useEffect(() => {
    if (!id) return;

    socket.emit("join_document_room", id);

    socket.on("receive_document", (data) => {
      setText(data);
    });

    socket.on("load_document", (content) => {
      setText(content);
    });

    socket.on("receive_cursor_position", (data) => {
      setCursors((prev) => {
        const filtered = prev.filter(
          (u) => u.username !== data.username
        );
        return [...filtered, data];
      });
    });

    return () => {
      socket.off("receive_document");
      socket.off("load_document");
      socket.off("receive_cursor_position");
    };
  }, [id]);

  const handleChange = (e) => {
    const value = e.target.value;
    setText(value);
    setSaveStatus("Saving...");

    socket.emit("cursor_position", {
      room: id,
      username,
      position: e.target.selectionStart,
    });

    clearTimeout(saveTimeout.current);

    saveTimeout.current = setTimeout(() => {
      socket.emit("document_change", {
        room: id,
        content: value,
        username,
      });
      setSaveStatus("Saved");
    }, 500);
  };

  return (
    <div className="h-full flex flex-col bg-bg-base relative z-10 overflow-hidden">
      {/* BACKGROUND EFFECTS */}
      <div className="absolute top-0 left-0 w-full h-[300px] bg-gradient-to-b from-sky-500/10 to-transparent pointer-events-none z-0"></div>
      <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-purple-500/10 rounded-full blur-[100px] pointer-events-none z-0 mix-blend-screen"></div>

      {/* EDITOR HEADER */}
      <motion.div 
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="glass-panel border-x-0 border-t-0 p-4 md:p-5 flex items-center justify-between shrink-0 relative z-20 shadow-[0_4px_30px_rgba(0,0,0,0.3)] backdrop-blur-xl"
      >
        <div className="flex items-center gap-4 md:gap-6">
          <button 
            onClick={() => navigate("/documents")}
            className="w-11 h-11 rounded-2xl flex-center bg-white/[0.03] hover:bg-white/[0.08] border border-white/5 transition-all text-text-secondary hover:text-white hover:scale-105 active:scale-95"
          >
            <ArrowLeft size={22} />
          </button>
          
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-2xl bg-sky-500/10 border border-sky-500/20 flex-center shadow-lg shadow-sky-500/10 hidden sm:flex">
              <FileText className="text-sky-400" size={24} />
            </div>
            <div>
              <h1 className="text-xl md:text-2xl font-bold leading-tight text-white tracking-tight">{id}</h1>
              <div className="flex items-center gap-2 mt-1">
                <AnimatePresence mode="wait">
                  {saveStatus === 'Saved' ? (
                    <motion.span 
                      key="saved"
                      initial={{ opacity: 0, y: 5 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -5 }}
                      className="text-xs font-semibold flex items-center gap-1.5 text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-md border border-emerald-500/20"
                    >
                      <CheckCircle2 size={12} /> Saved to cloud
                    </motion.span>
                  ) : (
                    <motion.span 
                      key="saving"
                      initial={{ opacity: 0, y: 5 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -5 }}
                      className="text-xs font-semibold flex items-center gap-1.5 text-sky-400 bg-sky-500/10 px-2 py-0.5 rounded-md border border-sky-500/20"
                    >
                      <div className="w-3 h-3 rounded-full border-2 border-sky-400 border-t-transparent animate-spin"></div>
                      Saving changes...
                    </motion.span>
                  )}
                </AnimatePresence>
              </div>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-5">
          {/* USER AVATARS */}
          <div className="flex items-center -space-x-3 mr-2">
            <AnimatePresence>
              {cursors.map((user, i) => (
                <motion.div
                  initial={{ opacity: 0, scale: 0.5, x: 20 }}
                  animate={{ opacity: 1, scale: 1, x: 0 }}
                  exit={{ opacity: 0, scale: 0.5 }}
                  key={user.username}
                  className="w-10 h-10 rounded-full bg-gradient-to-br from-emerald-400 to-teal-600 flex-center border-[3px] border-[#0f172a] shadow-lg relative group"
                >
                  <span className="text-white text-sm font-bold">{user.username.charAt(0).toUpperCase()}</span>
                  
                  {/* Tooltip */}
                  <div className="absolute -bottom-10 left-1/2 -translate-x-1/2 bg-bg-elevated border border-white/10 px-3 py-1.5 rounded-lg text-xs font-bold text-white opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap shadow-xl pointer-events-none">
                    {user.username}
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
            
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-sky-400 to-indigo-600 flex-center border-[3px] border-[#0f172a] shadow-lg z-10 relative group">
              <span className="text-white text-sm font-bold">{username.charAt(0).toUpperCase()}</span>
              {/* Tooltip */}
              <div className="absolute -bottom-10 left-1/2 -translate-x-1/2 bg-bg-elevated border border-white/10 px-3 py-1.5 rounded-lg text-xs font-bold text-white opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap shadow-xl pointer-events-none">
                {username} (You)
              </div>
            </div>
          </div>
          
          <div className="hidden md:flex items-center gap-2 bg-white/[0.03] px-4 py-2 rounded-xl text-sm font-semibold text-text-secondary border border-white/5 shadow-inner">
            <div className="relative flex-center">
              <Users size={16} className="text-sky-400 relative z-10" />
              <div className="absolute inset-0 bg-sky-400/20 blur-md rounded-full"></div>
            </div>
            <span className="text-white">{cursors.length + 1}</span>
            <span>online</span>
          </div>
        </div>
      </motion.div>

      {/* EDITOR CANVAS */}
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1, duration: 0.5 }}
        className="flex-1 p-4 md:p-8 overflow-hidden relative z-10 flex justify-center"
      >
        <div className="w-full max-w-5xl h-full glass-panel rounded-3xl shadow-[0_20px_60px_-15px_rgba(0,0,0,0.5)] border border-white/10 overflow-hidden relative group">
          
          {/* Subtle gradient border effect */}
          <div className="absolute inset-0 bg-gradient-to-b from-white/5 to-transparent pointer-events-none rounded-3xl"></div>
          
          <textarea
            value={text}
            onChange={handleChange}
            placeholder="Start typing to collaborate in real-time..."
            className="w-full h-full bg-transparent border-none outline-none resize-none p-8 md:p-12 text-lg md:text-xl leading-[1.8] text-white/90 font-medium placeholder:text-text-tertiary relative z-10 custom-scrollbar"
            spellCheck="false"
          />
        </div>
      </motion.div>
    </div>
  );
}
