import { useEffect, useState, useRef } from "react";
import { MessageSquare, Users, Send, LogOut, Hash } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import socket from "../socket";

export default function Chat() {
  const [room, setRoom] = useState("");
  const [joinedRoom, setJoinedRoom] = useState(null);
  const [message, setMessage] = useState("");
  const [chat, setChat] = useState([]);
  const [users, setUsers] = useState([]);
  const [typingUser, setTypingUser] = useState("");
  const chatEndRef = useRef(null);
  const typingTimeout = useRef(null);

  const username = localStorage.getItem("username") || "User";

  // Scroll to bottom when chat updates
  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [chat, typingUser]);

  /* ================= USERS & TYPING ================= */
  useEffect(() => {
    socket.on("update_users", (data) => setUsers(data));
    socket.on("typing", (user) => setTypingUser(user));
    socket.on("stop_typing", () => setTypingUser(""));

    return () => {
      socket.off("update_users");
      socket.off("typing");
      socket.off("stop_typing");
    };
  }, []);

  /* ================= MESSAGES ================= */
  useEffect(() => {
    socket.on("receive_message", (data) => {
      setChat((prev) => [...prev, data]);
      socket.emit("message_seen", { room: data.room, id: data.id });
    });

    socket.on("previous_messages", (msgs) => setChat(msgs));

    socket.on("message_seen_update", (id) => {
      setChat((prev) =>
        prev.map((msg) => (msg.id === id ? { ...msg, status: "seen" } : msg))
      );
    });

    return () => {
      socket.off("receive_message");
      socket.off("previous_messages");
      socket.off("message_seen_update");
    };
  }, []);

  /* ================= ACTIONS ================= */
  const joinRoom = (e) => {
    e?.preventDefault();
    if (!room.trim()) return;
    setJoinedRoom(room);
    setChat([]);
    socket.emit("join_room", room, username);
    socket.emit("load_messages", room);
  };

  const leaveRoom = () => {
    socket.emit("leave_room");
    setJoinedRoom(null);
    setChat([]);
    setUsers([]);
  };

  const sendMessage = (e) => {
    e?.preventDefault();
    if (!message.trim()) return;

    const msgData = {
      id: Date.now(),
      room: joinedRoom,
      message,
      username,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      status: "sent",
    };

    socket.emit("send_message", msgData);
    setMessage("");
    socket.emit("stop_typing", { room: joinedRoom, username });
  };

  const handleTyping = (e) => {
    setMessage(e.target.value);
    if (!joinedRoom) return;

    socket.emit("typing", { room: joinedRoom, username });
    clearTimeout(typingTimeout.current);

    typingTimeout.current = setTimeout(() => {
      socket.emit("stop_typing", { room: joinedRoom, username });
    }, 1000);
  };

  return (
    <div className="h-full flex flex-col md:flex-row bg-bg-base relative z-10 overflow-hidden">
      {/* LEFT PANEL - ROOM CONTROLS */}
      <motion.div 
        initial={{ opacity: 0, x: -20 }}
        animate={{ opacity: 1, x: 0 }}
        className="w-full md:w-[340px] shrink-0 glass-panel border-y-0 border-l-0 p-6 flex flex-col gap-6 relative z-20 shadow-[10px_0_30px_-15px_rgba(0,0,0,0.5)]"
      >
        <div className="mt-2">
          <h2 className="text-2xl font-bold flex items-center gap-3 mb-2 text-white">
            <div className="w-10 h-10 rounded-xl bg-purple-500/20 border border-purple-500/30 flex-center">
              <MessageSquare className="text-purple-400" size={20} />
            </div>
            Team Chat
          </h2>
          <p className="text-sm text-text-secondary font-medium">Collaborate with your team in real-time.</p>
        </div>

        <AnimatePresence mode="wait">
          {!joinedRoom ? (
            <motion.form 
              key="join"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              onSubmit={joinRoom} 
              className="bg-white/[0.02] p-5 rounded-3xl border border-white/5 shadow-inner"
            >
              <h3 className="font-bold mb-4 text-white text-center">Join a Workspace</h3>
              <div className="relative mb-5">
                <Hash className="absolute left-4 top-1/2 -translate-y-1/2 text-text-tertiary" size={18} />
                <input
                  placeholder="room-id"
                  value={room}
                  onChange={(e) => setRoom(e.target.value.toLowerCase().replace(/\s+/g, '-'))}
                  className="input-modern !pl-10"
                  required
                />
              </div>
              <button type="submit" className="btn-primary w-full py-3.5 text-[15px]">
                Join Room
              </button>
            </motion.form>
          ) : (
            <motion.div 
              key="room-info"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="flex flex-col h-full gap-6"
            >
              <div className="bg-white/[0.02] p-5 rounded-3xl border border-white/5 relative overflow-hidden">
                <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-purple-500 to-pink-500"></div>
                <div className="flex items-center justify-between mb-5 mt-1">
                  <div>
                    <h3 className="font-bold text-xl text-white flex items-center gap-1.5">
                      <Hash className="text-purple-400" size={20} />
                      {joinedRoom}
                    </h3>
                    <p className="text-xs text-emerald-400 flex items-center gap-1.5 mt-1.5 font-medium">
                      <span className="w-2 h-2 rounded-full bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.8)] animate-pulse"></span>
                      Connected securely
                    </p>
                  </div>
                </div>
                <button onClick={leaveRoom} className="btn-secondary w-full text-sm text-rose-400 border-rose-500/20 hover:bg-rose-500/10 hover:border-rose-500/30 transition-all">
                  <LogOut size={16} /> Leave Room
                </button>
              </div>

              <div className="bg-white/[0.02] p-5 rounded-3xl border border-white/5 flex-1 overflow-y-auto min-h-0">
                <h4 className="font-bold mb-4 flex items-center gap-2 text-sm text-text-secondary sticky top-0 bg-bg-surface/80 backdrop-blur-md py-1 z-10">
                  <Users size={16} /> Online Members ({users.length})
                </h4>
                <div className="space-y-3 pt-2">
                  <AnimatePresence>
                    {users.map((u, i) => (
                      <motion.div 
                        initial={{ opacity: 0, x: -10 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, scale: 0.9 }}
                        key={i} 
                        className="flex items-center gap-3 bg-white/5 p-2.5 rounded-xl border border-white/5 hover:bg-white/10 transition-colors"
                      >
                        <div className="w-9 h-9 rounded-full bg-gradient-to-br from-indigo-500 to-purple-600 flex-center shrink-0 shadow-md">
                          <span className="text-white text-xs font-bold">{u.charAt(0).toUpperCase()}</span>
                        </div>
                        <span className="text-sm font-semibold text-white truncate flex-1">{u}</span>
                        <span className="w-2 h-2 rounded-full bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.5)]"></span>
                      </motion.div>
                    ))}
                  </AnimatePresence>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>

      {/* RIGHT PANEL - CHAT MESSAGES */}
      <div className="flex-1 flex flex-col relative">
        <div className="absolute inset-0 bg-gradient-to-br from-bg-surface via-bg-base to-bg-elevated z-0"></div>
        <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-[0.03] z-0"></div>
        
        {/* HEADER */}
        <div className="glass-panel border-x-0 border-t-0 p-4 px-8 flex items-center justify-between relative z-10 shrink-0 shadow-sm">
          <div className="flex items-center gap-3">
            {joinedRoom && (
              <div className="w-10 h-10 rounded-full bg-purple-500/20 border border-purple-500/30 flex-center lg:hidden">
                <Hash className="text-purple-400" size={18} />
              </div>
            )}
            <h2 className="text-xl font-bold text-white">
              {joinedRoom ? `#${joinedRoom}` : "Select a room"}
            </h2>
          </div>
          {joinedRoom && (
            <div className="flex items-center gap-2 text-sm font-medium text-purple-300 bg-purple-500/10 border border-purple-500/20 px-4 py-2 rounded-full">
              <Users size={16} /> {users.length} Online
            </div>
          )}
        </div>

        {/* MESSAGES AREA */}
        <div className="flex-1 overflow-y-auto p-6 md:p-8 space-y-6 relative z-10 scroll-smooth">
          {!joinedRoom ? (
            <div className="h-full flex flex-col items-center justify-center text-center">
              <div className="w-24 h-24 rounded-full bg-white/5 flex-center mb-6 border border-white/10 shadow-xl">
                <MessageSquare size={40} className="text-text-tertiary" />
              </div>
              <h3 className="text-2xl font-bold text-white mb-2">No Room Selected</h3>
              <p className="text-text-secondary text-lg">Join a room from the sidebar to start messaging.</p>
            </div>
          ) : chat.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center">
              <div className="w-20 h-20 rounded-full bg-purple-500/10 flex-center mb-5 border border-purple-500/20">
                <Send size={32} className="text-purple-400 ml-1" />
              </div>
              <h3 className="text-xl font-bold text-white mb-2">It's quiet here...</h3>
              <p className="text-text-secondary">Be the first to say hello to the team!</p>
            </div>
          ) : (
            <div className="space-y-6">
              <AnimatePresence initial={false}>
                {chat.map((msg, i) => {
                  const isMe = msg.username === username;
                  const isSequential = i > 0 && chat[i-1].username === msg.username;
                  
                  return (
                    <motion.div 
                      initial={{ opacity: 0, y: 10, scale: 0.98 }}
                      animate={{ opacity: 1, y: 0, scale: 1 }}
                      transition={{ type: "spring", stiffness: 400, damping: 30 }}
                      key={msg.id || i} 
                      className={`flex flex-col ${isMe ? "items-end" : "items-start"} ${isSequential ? "mt-2" : "mt-6"}`}
                    >
                      <div className={`flex items-end gap-3 max-w-[85%] md:max-w-[70%] ${isMe ? "flex-row-reverse" : "flex-row"}`}>
                        
                        {!isSequential && (
                          <div className="w-10 h-10 rounded-full shrink-0 flex-center text-sm font-bold shadow-md z-10 mb-1"
                               style={{ background: isMe ? 'linear-gradient(135deg, #6366f1, #a855f7)' : 'linear-gradient(135deg, #3f3f46, #27272a)' }}>
                            <span className="text-white">{msg.username.charAt(0).toUpperCase()}</span>
                          </div>
                        )}
                        {isSequential && <div className="w-10 shrink-0"></div>}
                        
                        <div className="flex flex-col gap-1 w-full">
                          {!isMe && !isSequential && (
                            <span className="text-sm font-bold text-purple-400 ml-1">{msg.username}</span>
                          )}
                          
                          <div className={`p-4 rounded-3xl shadow-sm relative group ${
                            isMe 
                              ? "bg-gradient-to-br from-indigo-500 to-purple-600 text-white rounded-br-sm" 
                              : "bg-white/10 backdrop-blur-md border border-white/5 text-white rounded-bl-sm"
                          }`}>
                            <p className="leading-relaxed text-[15px]">{msg.message}</p>
                          </div>
                        </div>
                      </div>
                      
                      <div className={`text-xs font-medium text-text-tertiary mt-1.5 ${isMe ? "mr-[52px]" : "ml-[52px]"}`}>
                        {msg.time} {isMe && <span className="ml-2 text-indigo-400/80 capitalize">{msg.status}</span>}
                      </div>
                    </motion.div>
                  );
                })}
              </AnimatePresence>
            </div>
          )}
          
          {typingUser && typingUser !== username && (
            <motion.div 
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="flex items-center gap-3 text-sm text-text-tertiary font-medium ml-12"
            >
              <div className="bg-white/10 backdrop-blur-md border border-white/5 rounded-full px-4 py-2.5 flex items-center gap-2">
                <span className="flex gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-purple-400 animate-bounce" style={{ animationDelay: '0ms' }}></span>
                  <span className="w-1.5 h-1.5 rounded-full bg-purple-400 animate-bounce" style={{ animationDelay: '150ms' }}></span>
                  <span className="w-1.5 h-1.5 rounded-full bg-purple-400 animate-bounce" style={{ animationDelay: '300ms' }}></span>
                </span>
              </div>
              {typingUser} is typing...
            </motion.div>
          )}
          <div ref={chatEndRef} className="h-4" />
        </div>

        {/* INPUT AREA */}
        <div className="glass-panel border-x-0 border-b-0 p-4 md:p-6 relative z-10 shrink-0 shadow-[0_-10px_30px_-15px_rgba(0,0,0,0.5)]">
          <form onSubmit={sendMessage} className="flex gap-3 w-full mx-auto relative">
            <input
              value={message}
              onChange={handleTyping}
              placeholder={joinedRoom ? `Message #${joinedRoom}...` : "Join a room first"}
              disabled={!joinedRoom}
              className="input-modern bg-bg-surface/80 flex-1 disabled:opacity-50 !rounded-full !py-4 !pl-6 !pr-16 shadow-inner text-[15px]"
            />
            <button 
              type="submit" 
              disabled={!joinedRoom || !message.trim()}
              className="absolute right-2 top-1/2 -translate-y-1/2 btn-primary shrink-0 w-11 h-11 !p-0 rounded-full disabled:opacity-0 disabled:scale-90 transition-all duration-300"
            >
              <Send size={18} className="ml-0.5" />
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}