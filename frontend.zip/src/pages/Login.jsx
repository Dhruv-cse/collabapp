import { useState, useEffect } from "react";
import { useNavigate, Link } from "react-router-dom";
import { Sparkles, FileText, MessageSquare, ArrowRight } from "lucide-react";
import axios from "axios";
import { motion, AnimatePresence } from "framer-motion";

function Login() {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    email: "",
    password: "",
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const words = ["in real-time.", "with your team.", "from anywhere.", "seamlessly."];
  const [currentWordIndex, setCurrentWordIndex] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentWordIndex((prev) => (prev + 1) % words.length);
    }, 3000);
    return () => clearInterval(interval);
  }, [words.length]);

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
    setError("");
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      const res = await axios.post(
        "http://localhost:5000/api/auth/login",
        formData
      );

      localStorage.setItem("token", res.data.token);
      if (res.data.user && res.data.user.name) {
        localStorage.setItem("username", res.data.user.name);
      }

      navigate("/dashboard");
    } catch (error) {
      setError(error.response?.data?.message || "Login failed");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex bg-bg-base overflow-hidden selection:bg-violet-500/30">
      {/* LEFT SIDE - POSTER (Vibrant Gradient for Light Theme contrast) */}
      <div className="hidden lg:flex lg:w-1/2 relative overflow-hidden flex-col justify-center p-12 lg:p-20 bg-gradient-to-br from-violet-600 via-indigo-600 to-sky-600">
        <div className="absolute top-0 left-0 w-full h-full opacity-60 pointer-events-none z-0" style={{ backgroundImage: "radial-gradient(circle at 20% 30%, rgba(255, 255, 255, 0.15) 0%, transparent 50%), radial-gradient(circle at 80% 70%, rgba(255, 255, 255, 0.1) 0%, transparent 50%)" }}></div>
        <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-10 pointer-events-none z-0 mix-blend-overlay"></div>
        
        <motion.div 
          initial={{ opacity: 0, x: -50 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
          className="relative z-10 max-w-2xl mx-auto"
        >
          <div className="mb-12">
            <div className="w-16 h-16 rounded-3xl bg-white/20 backdrop-blur-md flex-center shadow-[0_0_40px_rgba(255,255,255,0.2)] mb-8 border border-white/30">
              <Sparkles className="text-white" size={32} />
            </div>
            <h1 className="text-6xl xl:text-7xl font-black mb-6 leading-[1.1] text-white tracking-tight">
              Build together,<br/>
              <div className="h-[80px] sm:h-[90px] xl:h-[100px] flex items-center mt-2 overflow-hidden">
                <AnimatePresence mode="wait">
                  <motion.span
                    key={currentWordIndex}
                    initial={{ y: 50, opacity: 0 }}
                    animate={{ y: 0, opacity: 1 }}
                    exit={{ y: -50, opacity: 0 }}
                    transition={{ duration: 0.5, ease: "circOut" }}
                    className="text-white inline-block py-2"
                  >
                    {words[currentWordIndex]}
                  </motion.span>
                </AnimatePresence>
              </div>
            </h1>
            
            <p className="text-xl xl:text-2xl text-white/80 leading-relaxed mb-12 font-medium max-w-lg">
              CollabSync is the ultimate workspace for modern teams. Write documents, chat instantly, and manage your projects without ever switching tabs.
            </p>
          </div>
          
          <div className="space-y-6 w-full max-w-md">
            <motion.div whileHover={{ scale: 1.02 }} className="group flex items-center gap-5 bg-white/10 p-5 rounded-3xl border border-white/20 backdrop-blur-md hover:bg-white/20 transition-all duration-300 cursor-pointer shadow-lg shadow-black/10">
              <div className="w-12 h-12 rounded-2xl bg-white/20 flex-center shrink-0 group-hover:scale-110 transition-all duration-300">
                <FileText className="text-white" size={24} />
              </div>
              <div>
                <h3 className="font-bold text-white text-lg">Live Documents</h3>
                <p className="text-sm text-white/80">Collaborate with multiplayer cursors.</p>
              </div>
            </motion.div>

            <motion.div whileHover={{ scale: 1.02 }} className="group flex items-center gap-5 bg-white/10 p-5 rounded-3xl border border-white/20 backdrop-blur-md hover:bg-white/20 transition-all duration-300 cursor-pointer shadow-lg shadow-black/10">
              <div className="w-12 h-12 rounded-2xl bg-white/20 flex-center shrink-0 group-hover:scale-110 transition-all duration-300">
                <MessageSquare className="text-white" size={24} />
              </div>
              <div>
                <h3 className="font-bold text-white text-lg">Team Chat</h3>
                <p className="text-sm text-white/80">Communicate instantly with your team.</p>
              </div>
            </motion.div>
          </div>
        </motion.div>
      </div>

      {/* RIGHT SIDE - LOGIN */}
      <div className="w-full lg:w-1/2 flex items-center justify-center p-6 sm:p-12 relative z-10 bg-bg-base">
        
        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="w-full max-w-[440px]"
        >
          {/* Mobile Only Header */}
          <div className="lg:hidden text-center mb-10 mt-4">
            <div className="w-14 h-14 rounded-3xl bg-gradient-to-br from-violet-500 to-indigo-600 flex-center mx-auto mb-5 shadow-lg shadow-violet-500/30">
              <Sparkles className="text-white" size={28} />
            </div>
            <h1 className="text-4xl font-extrabold mb-3 text-text-primary tracking-tight">CollabSync</h1>
            <p className="text-text-secondary text-sm font-medium">Sign in to continue</p>
          </div>

          <div className="glass-panel rounded-[32px] p-8 sm:p-10 lg:p-12 relative overflow-hidden border border-border-light bg-white shadow-[0_8px_30px_rgb(0,0,0,0.04)]">
            <div className="absolute top-0 left-0 w-full h-1.5 bg-gradient-to-r from-violet-500 via-indigo-500 to-sky-500"></div>
            
            <div className="mb-10">
              <h2 className="text-3xl font-bold mb-3 text-text-primary tracking-tight">Welcome back</h2>
              <p className="text-text-secondary font-medium">Enter your credentials to access your workspace.</p>
            </div>

            {error && (
              <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} className="mb-8 p-4 rounded-2xl bg-rose-50 border border-rose-100 text-rose-600 text-sm font-semibold flex items-center gap-3">
                <div className="w-2 h-2 rounded-full bg-rose-500 shrink-0 animate-pulse"></div>
                {error}
              </motion.div>
            )}

            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label className="block text-sm font-semibold text-text-secondary mb-2 ml-1">Email Address</label>
                <input
                  type="email"
                  name="email"
                  placeholder="name@company.com"
                  onChange={handleChange}
                  required
                  className="input-modern"
                />
              </div>

              <div>
                <div className="flex items-center justify-between mb-2 ml-1 mr-1">
                  <label className="block text-sm font-semibold text-text-secondary">Password</label>
                  <a href="#" className="text-xs text-violet-600 hover:text-violet-500 transition-colors font-bold">Forgot password?</a>
                </div>
                <input
                  type="password"
                  name="password"
                  placeholder="••••••••"
                  onChange={handleChange}
                  required
                  className="input-modern"
                />
              </div>

              <button
                type="submit"
                disabled={loading}
                className="btn-primary w-full py-4 mt-8 text-[16px]"
              >
                {loading ? "Signing in..." : (
                  <>
                    Sign In <ArrowRight size={20} />
                  </>
                )}
              </button>
            </form>

            <p className="mt-10 text-center text-sm font-medium text-text-secondary">
              Don't have an account?{" "}
              <Link to="/signup" className="text-violet-600 hover:text-violet-500 transition-colors font-bold ml-1">
                Create one now
              </Link>
            </p>
          </div>
        </motion.div>
      </div>
    </div>
  );
}

export default Login;