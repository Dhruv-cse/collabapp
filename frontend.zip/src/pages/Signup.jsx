import { useState, useEffect } from "react";
import { useNavigate, Link } from "react-router-dom";
import { Sparkles, FileText, MessageSquare, ArrowRight } from "lucide-react";
import axios from "axios";
import { motion, AnimatePresence } from "framer-motion";

function Signup() {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    password: "",
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const words = ["in real-time.", "with your team.", "from anywhere.", "seamlessly."];
  const [currentWordIndex, setCurrentWordIndex] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentWordIndex((prev) => (prev + 1) % words.length);
    }, 3000);
    return () => clearInterval(interval);
  }, [words.length]);

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
    setError("");
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      const res = await axios.post(
        "http://localhost:5000/api/auth/signup",
        formData
      );

      localStorage.setItem("token", res.data.token);
      if (res.data.user && res.data.user.name) {
        localStorage.setItem("username", res.data.user.name);
      }

      navigate("/dashboard");
    } catch (error) {
      setError(error.response?.data?.message || "Signup failed");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex bg-bg-base overflow-hidden selection:bg-purple-500/30">
      {/* LEFT SIDE - POSTER */}
      <div className="hidden lg:flex lg:w-1/2 relative overflow-hidden flex-col justify-center p-12 lg:p-20">
        <div className="absolute inset-0 bg-gradient-to-br from-bg-surface via-bg-base to-bg-elevated z-0"></div>
        <div className="absolute top-0 left-0 w-full h-full opacity-60 pointer-events-none z-0" style={{ backgroundImage: "radial-gradient(circle at 80% 30%, rgba(192, 132, 252, 0.2) 0%, transparent 50%), radial-gradient(circle at 20% 70%, rgba(56, 189, 248, 0.2) 0%, transparent 50%)" }}></div>
        <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-[0.03] pointer-events-none z-0"></div>
        
        <motion.div 
          initial={{ opacity: 0, x: -50 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
          className="relative z-10 max-w-2xl mx-auto"
        >
          <div className="mb-12">
            <div className="w-16 h-16 rounded-3xl bg-gradient-to-br from-indigo-500 to-purple-600 flex-center shadow-[0_0_40px_rgba(168,85,247,0.4)] mb-8">
              <Sparkles className="text-white" size={32} />
            </div>
            <h1 className="text-6xl xl:text-7xl font-black mb-6 leading-[1.1] text-white tracking-tight">
              Create together,<br/>
              <div className="h-[80px] sm:h-[90px] xl:h-[100px] flex items-center mt-2 overflow-hidden">
                <AnimatePresence mode="wait">
                  <motion.span
                    key={currentWordIndex}
                    initial={{ y: 50, opacity: 0 }}
                    animate={{ y: 0, opacity: 1 }}
                    exit={{ y: -50, opacity: 0 }}
                    transition={{ duration: 0.5, ease: "circOut" }}
                    className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 via-purple-400 to-pink-400 inline-block py-2"
                  >
                    {words[currentWordIndex]}
                  </motion.span>
                </AnimatePresence>
              </div>
            </h1>
            
            <p className="text-xl xl:text-2xl text-text-secondary leading-relaxed mb-12 font-medium max-w-lg">
              Join CollabSync and unlock the ultimate workspace for your team. Start collaborating instantly.
            </p>
          </div>
          
          <div className="space-y-6 w-full max-w-md">
            <motion.div whileHover={{ scale: 1.02 }} className="group flex items-center gap-5 bg-white/[0.03] p-5 rounded-3xl border border-white/5 backdrop-blur-md hover:bg-white/[0.06] hover:border-white/10 transition-all duration-300 cursor-pointer shadow-lg shadow-black/20">
              <div className="w-12 h-12 rounded-2xl bg-indigo-500/10 border border-indigo-500/20 flex-center shrink-0 group-hover:scale-110 group-hover:bg-indigo-500/20 transition-all duration-300">
                <FileText className="text-indigo-400" size={24} />
              </div>
              <div>
                <h3 className="font-bold text-white text-lg group-hover:text-indigo-300 transition-colors">Live Documents</h3>
                <p className="text-sm text-text-secondary">Collaborate with multiplayer cursors.</p>
              </div>
            </motion.div>

            <motion.div whileHover={{ scale: 1.02 }} className="group flex items-center gap-5 bg-white/[0.03] p-5 rounded-3xl border border-white/5 backdrop-blur-md hover:bg-white/[0.06] hover:border-white/10 transition-all duration-300 cursor-pointer shadow-lg shadow-black/20">
              <div className="w-12 h-12 rounded-2xl bg-pink-500/10 border border-pink-500/20 flex-center shrink-0 group-hover:scale-110 group-hover:bg-pink-500/20 transition-all duration-300">
                <MessageSquare className="text-pink-400" size={24} />
              </div>
              <div>
                <h3 className="font-bold text-white text-lg group-hover:text-pink-300 transition-colors">Team Chat</h3>
                <p className="text-sm text-text-secondary">Communicate instantly with your team.</p>
              </div>
            </motion.div>
          </div>
        </motion.div>
      </div>

      {/* RIGHT SIDE - SIGNUP */}
      <div className="w-full lg:w-1/2 flex items-center justify-center p-6 sm:p-12 relative z-10">
        
        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="w-full max-w-[440px]"
        >
          {/* Mobile Only Header */}
          <div className="lg:hidden text-center mb-10 mt-4">
            <div className="w-14 h-14 rounded-3xl bg-gradient-to-br from-indigo-500 to-purple-600 flex-center mx-auto mb-5 shadow-[0_0_30px_rgba(168,85,247,0.4)]">
              <Sparkles className="text-white" size={28} />
            </div>
            <h1 className="text-4xl font-extrabold mb-3 text-gradient-accent tracking-tight">CollabSync</h1>
            <p className="text-text-secondary text-sm font-medium">Create an account to start</p>
          </div>

          <div className="glass-panel rounded-[32px] p-8 sm:p-10 lg:p-12 shadow-[0_20px_60px_-15px_rgba(0,0,0,0.5)] relative overflow-hidden border border-white/10">
            <div className="absolute top-0 left-0 w-full h-1.5 bg-gradient-to-r from-purple-500 via-pink-500 to-rose-500"></div>
            
            <div className="mb-10">
              <h2 className="text-3xl font-bold mb-3 text-white tracking-tight">Create Account</h2>
              <p className="text-text-secondary font-medium">Join us to start collaborating instantly.</p>
            </div>

            {error && (
              <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} className="mb-8 p-4 rounded-2xl bg-rose-500/10 border border-rose-500/20 text-rose-400 text-sm font-semibold flex items-center gap-3">
                <div className="w-2 h-2 rounded-full bg-rose-500 shrink-0 animate-pulse"></div>
                {error}
              </motion.div>
            )}

            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label className="block text-sm font-semibold text-text-secondary mb-2 ml-1">Full Name</label>
                <input
                  type="text"
                  name="name"
                  placeholder="John Doe"
                  onChange={handleChange}
                  required
                  className="input-modern"
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-text-secondary mb-2 ml-1">Email Address</label>
                <input
                  type="email"
                  name="email"
                  placeholder="name@company.com"
                  onChange={handleChange}
                  required
                  className="input-modern"
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-text-secondary mb-2 ml-1">Password</label>
                <input
                  type="password"
                  name="password"
                  placeholder="••••••••"
                  onChange={handleChange}
                  required
                  className="input-modern"
                />
              </div>

              <button
                type="submit"
                disabled={loading}
                className="btn-primary w-full py-4 mt-8 text-[16px]"
              >
                {loading ? "Creating account..." : (
                  <>
                    Sign Up <ArrowRight size={20} />
                  </>
                )}
              </button>
            </form>

            <p className="mt-10 text-center text-sm font-medium text-text-secondary">
              Already have an account?{" "}
              <Link to="/login" className="text-purple-400 hover:text-purple-300 transition-colors font-bold ml-1">
                Sign in
              </Link>
            </p>
          </div>
        </motion.div>
      </div>
    </div>
  );
}

export default Signup;