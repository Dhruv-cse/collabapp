import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { FileText, Plus, Search, Clock, ChevronRight } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

export default function Documents() {
  const [documents, setDocuments] = useState([]);
  const [newDoc, setNewDoc] = useState("");
  const [searchQuery, setSearchQuery] = useState("");
  const navigate = useNavigate();

  useEffect(() => {
    const savedDocs = JSON.parse(localStorage.getItem("documents")) || [];
    setDocuments(savedDocs);
  }, []);

  const createDocument = (e) => {
    e?.preventDefault();
    if (!newDoc.trim()) return;

    const docName = newDoc.trim().toLowerCase().replace(/\s+/g, '-');
    if (documents.includes(docName)) {
      alert("Document already exists!");
      return;
    }

    const updatedDocs = [docName, ...documents];
    setDocuments(updatedDocs);
    localStorage.setItem("documents", JSON.stringify(updatedDocs));
    setNewDoc("");
    navigate(`/editor/${docName}`);
  };

  const openDocument = (docName) => {
    navigate(`/editor/${docName}`);
  };

  const filteredDocs = documents.filter(doc => 
    doc.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const containerVariants = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: { staggerChildren: 0.05 }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, scale: 0.95, y: 10 },
    show: { opacity: 1, scale: 1, y: 0, transition: { type: "spring", stiffness: 300, damping: 24 } }
  };

  return (
    <div className="p-8 md:p-12 max-w-7xl mx-auto h-full flex flex-col relative z-10">
      
      <motion.div 
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 mb-10"
      >
        <div>
          <h1 className="text-4xl md:text-5xl font-extrabold mb-3 tracking-tight">Documents</h1>
          <p className="text-text-secondary text-lg font-medium">Create and manage your collaborative workspaces</p>
        </div>
        
        <form onSubmit={createDocument} className="flex gap-3 w-full lg:w-auto mt-4 lg:mt-0">
          <input
            value={newDoc}
            onChange={(e) => setNewDoc(e.target.value)}
            placeholder="New document name..."
            className="input-modern md:w-72 shadow-inner"
          />
          <button type="submit" className="btn-primary shrink-0 px-6">
            <Plus size={22} className="mr-1" />
            <span className="font-bold">Create</span>
          </button>
        </form>
      </motion.div>

      <motion.div 
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.1 }}
        className="glass-panel p-2 rounded-2xl flex items-center gap-4 mb-10 shadow-lg"
      >
        <Search className="text-sky-400 ml-4" size={22} />
        <input 
          type="text" 
          placeholder="Search documents..." 
          className="bg-transparent border-none text-white outline-none flex-1 py-3 pr-4 placeholder:text-text-tertiary font-medium text-[16px]"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
        />
      </motion.div>

      <div className="flex-1 overflow-y-auto pb-12 pr-2">
        {documents.length === 0 ? (
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="h-[400px] flex flex-col items-center justify-center text-center glass-panel rounded-3xl border-dashed border-2 border-white/10"
          >
            <div className="w-20 h-20 rounded-3xl bg-sky-500/10 border border-sky-500/20 flex-center mb-6 shadow-lg shadow-sky-500/10">
              <FileText size={36} className="text-sky-400" />
            </div>
            <h3 className="text-2xl font-bold mb-3 text-white">No documents yet</h3>
            <p className="text-text-secondary max-w-md text-lg font-medium">Create your first document above to start collaborating with your team.</p>
          </motion.div>
        ) : (
          <AnimatePresence mode="popLayout">
            {filteredDocs.length === 0 ? (
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="text-center py-20 text-text-tertiary text-lg font-medium"
              >
                No documents found matching "<span className="text-white">{searchQuery}</span>"
              </motion.div>
            ) : (
              <motion.div 
                variants={containerVariants}
                initial="hidden"
                animate="show"
                className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6"
              >
                {filteredDocs.map((doc, i) => (
                  <motion.div
                    variants={itemVariants}
                    layoutId={`doc-${doc}`}
                    key={doc}
                    onClick={() => openDocument(doc)}
                    className="card-hover p-6 rounded-3xl cursor-pointer group flex flex-col items-start h-[180px]"
                  >
                    <div className="w-14 h-14 rounded-2xl bg-sky-500/10 border border-sky-500/20 flex-center mb-auto shrink-0 group-hover:scale-110 group-hover:bg-sky-500/20 transition-all duration-300">
                      <FileText className="text-sky-400" size={26} />
                    </div>
                    
                    <button className="absolute top-6 right-6 w-10 h-10 rounded-full flex-center bg-white/5 opacity-0 group-hover:opacity-100 transition-all duration-300 hover:bg-white/10 text-white translate-x-2 group-hover:translate-x-0">
                      <ChevronRight size={20} />
                    </button>
                    
                    <div className="w-full mt-4">
                      <h2 className="text-xl font-bold mb-2 truncate text-white group-hover:text-sky-300 transition-colors">{doc}</h2>
                      <div className="flex items-center gap-2 text-sm text-text-tertiary font-medium">
                        <Clock size={16} />
                        <span>Recently edited</span>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </motion.div>
            )}
          </AnimatePresence>
        )}
      </div>
    </div>
  );
}