import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  FileText,
  MessageSquare,
  Users,
  Activity,
  ArrowRight,
  Plus,
} from "lucide-react";
import socket from "../socket";

export default function Dashboard() {
  const navigate = useNavigate();
  const username = localStorage.getItem("username") || "User";

  const [docCount, setDocCount] = useState(0);

  useEffect(() => {
    const docs =
      JSON.parse(localStorage.getItem("documents")) || [];
    setDocCount(docs.length);

    socket.on("connect", () => {
      console.log("Connected:", socket.id);
    });

    return () => {
      socket.off("connect");
    };
  }, []);

  const recentDocs =
    JSON.parse(localStorage.getItem("documents")) || [];

  return (
    <div className="workspace-page p-8">
      {/* HERO */}
      <div className="glass-panel rounded-3xl p-8 mb-8">
        <div className="flex flex-col lg:flex-row justify-between gap-6">
          <div>
            <p className="text-sm text-violet-500 font-semibold mb-2">
              Workspace Overview
            </p>

            <h1 className="text-5xl font-bold text-text-primary mb-3">
              Welcome back,
              <span className="text-gradient-accent">
                {" "}
                {username}
              </span>
            </h1>

            <p className="text-lg text-text-secondary max-w-2xl">
              Manage documents, collaborate with your team and
              stay productive from a single workspace.
            </p>
          </div>

          <button
            onClick={() => navigate("/documents")}
            className="btn-primary h-fit"
          >
            <Plus size={18} />
            New Document
          </button>
        </div>
      </div>

      {/* STATS */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-5 mb-8">
        <div className="card-hover p-6">
          <FileText
            size={22}
            className="text-violet-500 mb-3"
          />

          <h2 className="text-4xl font-bold">
            {docCount}
          </h2>

          <p className="text-text-secondary mt-1">
            Documents
          </p>
        </div>

        <div className="card-hover p-6">
          <MessageSquare
            size={22}
            className="text-blue-500 mb-3"
          />

          <h2 className="text-4xl font-bold">5</h2>

          <p className="text-text-secondary mt-1">
            Chats
          </p>
        </div>

        <div className="card-hover p-6">
          <Users
            size={22}
            className="text-purple-500 mb-3"
          />

          <h2 className="text-4xl font-bold">8</h2>

          <p className="text-text-secondary mt-1">
            Members
          </p>
        </div>

        <div className="card-hover p-6">
          <Activity
            size={22}
            className="text-emerald-500 mb-3"
          />

          <h2 className="text-4xl font-bold">
            100%
          </h2>

          <p className="text-text-secondary mt-1">
            Status
          </p>
        </div>
      </div>

      {/* CONTENT */}
      <div className="grid lg:grid-cols-3 gap-6">
        {/* RECENT DOCS */}
        <div className="lg:col-span-2 glass-panel rounded-3xl p-6">
          <div className="flex justify-between items-center mb-5">
            <h2 className="text-xl font-bold">
              Recent Documents
            </h2>

            <button
              onClick={() => navigate("/documents")}
              className="text-violet-500 font-medium flex items-center gap-1"
            >
              View All
              <ArrowRight size={16} />
            </button>
          </div>

          <div className="space-y-3">
            {recentDocs.length > 0 ? (
              recentDocs.slice(0, 5).map((doc) => (
                <div
                  key={doc}
                  onClick={() =>
                    navigate(`/editor/${doc}`)
                  }
                  className="p-4 rounded-xl border border-slate-200 hover:bg-slate-50 cursor-pointer transition"
                >
                  <div className="flex items-center justify-between">
                    <span className="font-medium">
                      {doc}
                    </span>

                    <ArrowRight size={16} />
                  </div>
                </div>
              ))
            ) : (
              <div className="text-text-secondary py-8 text-center">
                No documents available
              </div>
            )}
          </div>
        </div>

        {/* SIDEBAR */}
        <div className="space-y-6">
          <div className="glass-panel rounded-3xl p-6">
            <h2 className="text-xl font-bold mb-4">
              Quick Actions
            </h2>

            <div className="space-y-3">
              <button
                onClick={() =>
                  navigate("/documents")
                }
                className="btn-secondary w-full"
              >
                Documents
              </button>

              <button
                onClick={() =>
                  navigate("/chat")
                }
                className="btn-secondary w-full"
              >
                Team Chat
              </button>
            </div>
          </div>

          <div className="glass-panel rounded-3xl p-6">
            <h2 className="text-xl font-bold mb-4">
              Workspace Status
            </h2>

            <div className="flex items-center gap-3">
              <span className="status-dot status-online"></span>

              <div>
                <p className="font-semibold">
                  All Systems Operational
                </p>

                <p className="text-sm text-text-secondary">
                  Real-time collaboration active
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}