import { useState } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import {
  Home,
  FileText,
  MessageSquare,
  LogOut,
  Menu,
  X,
  Sparkles,
  Search,
  Bell,
  Plus,
  Command,
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

export default function Layout({ children }) {
  const navigate = useNavigate();
  const location = useLocation();

  const [sidebarOpen, setSidebarOpen] = useState(false);

  const username = localStorage.getItem("username") || "User";

  const handleLogout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("username");
    navigate("/login");
  };

  const navItems = [
    {
      name: "Dashboard",
      path: "/dashboard",
      icon: Home,
    },
    {
      name: "Documents",
      path: "/documents",
      icon: FileText,
    },
    {
      name: "Team Chat",
      path: "/chat",
      icon: MessageSquare,
    },
  ];

  const SidebarContent = () => (
    <>
      {/* LOGO */}
      <div className="mb-10 mt-2 flex items-center gap-4">
        <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-violet-500 to-indigo-600 flex items-center justify-center shadow-lg shadow-violet-500/20">
          <Sparkles className="text-white" size={24} />
        </div>

        <div>
          <h1 className="text-xl font-extrabold text-gradient-accent">
            CollabSync
          </h1>

          <div className="flex items-center gap-2 mt-1">
            <span className="status-dot status-online"></span>
            <span className="text-xs text-text-tertiary font-medium">
              Workspace Active
            </span>
          </div>
        </div>
      </div>

      {/* NAVIGATION */}
      <div className="flex flex-col gap-3">
        {navItems.map((item) => {
          const isActive =
            location.pathname === item.path ||
            location.pathname.startsWith(`${item.path}/`);

          return (
            <button
              key={item.name}
              onClick={() => {
                navigate(item.path);
                setSidebarOpen(false);
              }}
              className={`relative flex items-center gap-4 p-3.5 rounded-2xl transition-all duration-300 font-medium overflow-hidden group ${
                isActive
                  ? "text-text-primary"
                  : "text-text-secondary hover:text-text-primary hover:bg-slate-100"
              }`}
            >
              {isActive && (
                <motion.div
                  layoutId="activeTab"
                  className="absolute inset-0 bg-violet-500/10 border border-violet-500/20 rounded-2xl"
                />
              )}

              <item.icon
                size={22}
                className={`relative z-10 ${
                  isActive
                    ? "text-violet-600"
                    : "text-text-tertiary group-hover:text-violet-500"
                }`}
              />

              <span className="relative z-10">{item.name}</span>
            </button>
          );
        })}
      </div>

      {/* CREATE BUTTON */}
      <div className="mt-6">
        <button
          onClick={() => navigate("/documents")}
          className="btn-primary w-full"
        >
          <Plus size={18} />
          New Document
        </button>
      </div>

      {/* PROFILE */}
      <div className="mt-auto pt-6 border-t border-border-light">
        <div className="flex items-center gap-4 mb-6 px-2">
          <div className="w-12 h-12 rounded-full bg-gradient-to-br from-violet-500 to-indigo-600 flex items-center justify-center text-white font-bold shadow-lg">
            {username.charAt(0).toUpperCase()}
          </div>

          <div className="flex-1 overflow-hidden">
            <p className="font-bold truncate text-text-primary">
              {username}
            </p>

            <p className="text-xs text-text-tertiary">
              Workspace Member
            </p>
          </div>
        </div>

        <button
          onClick={handleLogout}
          className="flex items-center gap-4 p-3.5 rounded-2xl w-full transition text-rose-500 hover:bg-rose-500/10 border border-transparent hover:border-rose-500/20 font-medium"
        >
          <LogOut size={20} />
          Logout
        </button>
      </div>
    </>
  );

  return (
    <div className="min-h-screen bg-bg-base flex overflow-hidden">

      {/* MOBILE MENU */}
      <button
        onClick={() => setSidebarOpen(true)}
        className="md:hidden fixed top-5 left-5 z-50 glass-panel p-3 rounded-2xl"
      >
        <Menu size={24} />
      </button>

      {/* MOBILE OVERLAY */}
      <AnimatePresence>
        {sidebarOpen && (
          <motion.div
            className="fixed inset-0 bg-black/40 backdrop-blur-sm z-40 md:hidden"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setSidebarOpen(false)}
          />
        )}
      </AnimatePresence>

      {/* MOBILE SIDEBAR */}
      <AnimatePresence>
        {sidebarOpen && (
          <motion.div
            className="fixed left-0 top-0 h-screen w-72 glass-panel z-50 p-6 flex flex-col md:hidden"
            initial={{ x: "-100%" }}
            animate={{ x: 0 }}
            exit={{ x: "-100%" }}
            transition={{
              type: "spring",
              stiffness: 300,
              damping: 30,
            }}
          >
            <button
              onClick={() => setSidebarOpen(false)}
              className="absolute top-6 right-6"
            >
              <X size={22} />
            </button>

            <SidebarContent />
          </motion.div>
        )}
      </AnimatePresence>

      {/* DESKTOP SIDEBAR */}
      <div className="hidden md:flex w-60 h-screen glass-panel border-r border-border-light p-6 flex-col shrink-0 sidebar-shadow">
        <SidebarContent />
      </div>

      {/* MAIN AREA */}
      <div className="flex-1 h-screen overflow-hidden flex flex-col">

        {/* TOPBAR */}
        <div className="h-16 bg-white/80 backdrop-blur-xl border-b border-border-light flex items-center justify-between px-6 lg:px-10 shrink-0 topbar-shadow">

          {/* SEARCH */}
          <div className="hidden md:flex items-center gap-3 bg-slate-100 border border-border-light rounded-2xl px-4 py-3 min-w-[340px]">

            <Search
              size={18}
              className="text-text-tertiary"
            />

            <input
              placeholder="Search workspace..."
              className="bg-transparent outline-none flex-1 text-sm"
            />

            <div className="flex items-center gap-1 text-xs text-text-tertiary">
              <Command size={12} />
              K
            </div>
          </div>

          {/* RIGHT */}
          <div className="flex items-center gap-4 ml-auto">

            <button className="relative w-11 h-11 rounded-2xl bg-white border border-border-light flex items-center justify-center hover:scale-105 transition">
              <Bell size={20} />

              <span className="absolute top-2 right-2 w-2 h-2 rounded-full bg-rose-500"></span>
            </button>

            <div className="hidden sm:flex items-center gap-3">
              <div className="text-right">
                <p className="font-semibold text-sm">
                  {username}
                </p>

                <p className="text-xs text-text-tertiary">
                  Workspace Member
                </p>
              </div>

              <div className="w-11 h-11 rounded-full bg-gradient-to-br from-violet-500 to-indigo-600 flex items-center justify-center text-white font-bold">
                {username.charAt(0).toUpperCase()}
              </div>
            </div>
          </div>
        </div>

        {/* PAGE CONTENT */}
        <div className="flex-1 overflow-y-auto workspace-page">
          <AnimatePresence mode="wait">
            <motion.div
              key={location.pathname}
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.25 }}
              className="min-h-full"
            >
              {children}
            </motion.div>
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
}